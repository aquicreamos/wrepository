
<style type="text/css">
form {
	text-align: center;
}
form {
	font-weight: bold;
}
</style>

<?php

echo "<form id='form1' name='placaout' method='post' action='revisa.php'>
  Inserta la placa a Buscar,  
  <label for='textfield'></label>
  <input type='text' name='textfield' id='textfield' />
  <input type='submit' name='button' value='Submit' />
</form>";

?>

