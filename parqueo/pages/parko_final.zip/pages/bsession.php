<?php

echo "
<div align='center'>
<form id='form1' name='Session' method='post' action='methsession.php'>
  <p>Usuario:  
    <label for='textfield'></label>
  <input type='text' name='user' id='textfield' />
  </p>
  <p>Contrasenia 
    <input type='password' name='pass' id='textfield2' />
  </p>
  <input name='btn' type='submit' />
</form>
</div>";

?>
