<?php
echo "<div class='nav-outer'>
	<ul class='hmenu'>
		<li>
			<a href='index1.php' class='active'>Inicio</a>
		</li>	
		<li>
			<a href='#'>INSCRIPCIONES</a>
		  <ul>
				<li>
                    <a href='index1.php?pg=usuario.php'>USUARIO</a>
                    <a href='index1.php?pg=in.php'>ENTRADA VEHICULO</a>
                </li>
				
			</ul>
		</li>
	</ul>
</div>";
?>