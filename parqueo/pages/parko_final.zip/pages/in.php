  <div align="center">
  <form action="registro.php" name="trabco3"  method="post" id="formu">

   	<hr>
	<table width="700" border="0">
        <tr>
        <td>Entrada de Vehiculos: Escriba la Placa del Vehiculo</td>
        <td><input type="text" name="placa" /></td>
        </tr>
        </table>
            <p><label>
              <input type="submit" name="ingresar" value="ENVIAR"/>
                           
  
            </label>
    </form> 


              </p>
               

           
    <hr />
